import express from 'express';
import cors from 'cors';
import { GoogleGenerativeAI } from '@google/generative-ai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

// Configuración de CORS para permitir solicitudes desde cualquier origen
const corsOptions = {
  origin: '*',  // Permitir todos los orígenes
  methods: ['GET', 'POST'],
};

app.use(cors(corsOptions));
app.use(express.json());

// Inicializar Gemini
const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);

app.post('/generar-receta', async (req, res) => {
  const { nombrePlato } = req.body;

  try {
    const model = genAI.getGenerativeModel({ model: 'models/gemini-2.0-flash' });

    const prompt = `Genera dos recetas completas para un plato con los siguientes ingredientes: "${nombrePlato}". Incluye ingredientes, preparación paso a paso, tiempo de cocción y algún consejo útil. Si no se ingresa palabras que sean ingredientes, poner "por favor ingrese ingredientes válidos".`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const receta = await response.text();

    res.json({ receta });
  } catch (error) {
    console.error('Error al generar la receta:', error);
    res.status(500).json({ error: 'No se pudo generar la receta.' });
  }
});

// Iniciar servidor
app.listen(port, () => {
  console.log(`Servidor corriendo en el puerto ${port}`);
});

// import express from 'express';
// import cors from 'cors';
// import { GoogleGenerativeAI } from '@google/generative-ai';
// import dotenv from 'dotenv';

// dotenv.config();

// const app = express();
// const port = process.env.PORT || 3000;

// // Configuración de CORS para permitir solo el dominio de tu frontend
// const corsOptions = {
//   origin: 'https://staging.d1gbl32lj73me7.amplifyapp.com', // Cambiar si tu dominio cambia
//   methods: ['GET', 'POST'],
// };

// app.use(cors(corsOptions));
// app.use(express.json());

// // Inicializar Gemini
// const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);

// app.post('/generar-receta', async (req, res) => {
//   const { nombrePlato } = req.body;

//   try {
//     const model = genAI.getGenerativeModel({ model: 'models/gemini-2.0-flash' });

//     const prompt = `Genera dos recetas completas para un plato con los siguientes ingredientes: "${nombrePlato}". Incluye ingredientes, preparación paso a paso, tiempo de cocción y algún consejo útil. Si no se ingresa palabras que sean ingredientes, poner "por favor ingrese ingredientes válidos".`;

//     const result = await model.generateContent(prompt);
//     const response = await result.response;
//     const receta = await response.text();

//     res.json({ receta });
//   } catch (error) {
//     console.error('Error al generar la receta:', error);
//     res.status(500).json({ error: 'No se pudo generar la receta.' });
//   }
// });

// // Iniciar servidor
// app.listen(port, () => {
//   console.log(`Servidor corriendo en el puerto ${port}`);
// });